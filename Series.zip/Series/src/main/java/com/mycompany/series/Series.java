package com.mycompany.series;

import java.util.Scanner;

public class Series {

    //Using an array that stores up to 50 series objects
    static SeriesModel[] seriesList = new SeriesModel[50];
    static int seriesCount = 0; //Tracks how many series are currently stored inside the array

    //This method allows the user to capture a new TV series by typing input
    public void CaptureSeries() {
        Scanner scan = new Scanner(System.in);
        System.out.println("CAPTURE A NEW SERIES");
        System.out.println("*************************************");

        //asks for the series ID which must be numeric
        String seriesId;
        while (true) {
            System.out.print("Enter the series ID: ");
            seriesId = scan.nextLine();
            if (!isNumeric(seriesId)) { //implements validation using helper method
                System.out.println("Invalid input! Series ID must be numeric.");
            } else {
                break;//exits the loop once valid
            }
        }

        System.out.print("Enter the series name: ");
        String seriesName = scan.nextLine();

        String age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            age = scan.nextLine();
            if (!isNumeric(age)) { //checks if the entered value is numeric
                System.out.println("You have entered an incorrect series age!!!\nPlease re-enter the series age >>>");
                continue;
            }
            int ageNum = Integer.parseInt(age);
            if (ageNum < 2 || ageNum > 18) { //checks if the age is within the range of 2 to 18 years old
                System.out.println("You have entered an incorrect series age!!!\nPlease re-enter >>>");
            } else {
                break;
            }
        }

        //asks for number of episodes
        String episodes;
        while (true) {
            System.out.print("Enter number of episodes: ");
            episodes = scan.nextLine();
            if (!isNumeric(episodes)) {
                System.out.println("Invalid input! Number of episodes must be numeric.");
            } else {
                break;
            }
        }

        //stores the captured series if the array is not full
        if (seriesCount < seriesList.length) {
            seriesList[seriesCount] = new SeriesModel(seriesId, seriesName, age, episodes);
            seriesCount++;//increates the count after adding
            System.out.println("\nSeries captured successfully!!!");
        } else {
            System.out.println("\nError: Series list is full. Cannot add more.");
        }
        promptReturnToMenu();
    }

    //my own helper method which checks if a given string can be safely converted into an interger
    static boolean isNumeric(String str) {
        try {
            Integer.parseInt(str);
            return true;//if numeric
        } catch (NumberFormatException e) {
            return false;//if not numeric
        }
    }

    //Allows user to search for a series by entering its ID
    public void SearchSeries() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the series ID to search : ");
        String id = scan.nextLine();

        //Loops through all stored series to check for a match
        for (int i = 0; i < seriesCount; i++) {
            if (seriesList[i].seriesId[0].equals(id)) {
                System.out.println("---------------------------------------");
                System.out.println(seriesList[i]);
                return;
            }
        }
        //if the loop finishes with no match
        System.out.println("Series with Series ID: " + id + " was not found!");
        System.out.println("\n---------------------------------------");

        promptReturnToMenu();
    }

    //Allows user to update the name, age restriction, and episodes to what they wish
    public void UpdateSeries() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the series ID to update : ");
        String id = scan.nextLine();

        for (int i = 0; i < seriesCount; i++) {
            if (seriesList[i].seriesId.equals(id)) {

                //Asks for new Name
                System.out.print("Enter the series name: ");
                String newName = scan.nextLine();

                //Asks for new Age
                String newAge;
                while (true) {
                    System.out.print("Enter the age restriction: ");
                    newAge = scan.nextLine();
                    if (!isNumeric(newAge)) {
                        System.out.println("Invalid input! Age must be numeric.");
                        continue;
                    }
                    int ageNum = Integer.parseInt(newAge);
                    if (ageNum < 2 || ageNum > 18) {
                        System.out.println("Invalid input! Age must be between 2 and 18.");
                    } else {
                        break;
                    }
                }

                //Asks for new Episodes
                System.out.print("Enter the number of episodes: ");
                String newEpisodes = scan.nextLine();

                //stores new values into the SeriesModel objects
                seriesList[i].seriesName[0] = newName;
                seriesList[i].seriesAge[0] = newAge;
                seriesList[i].seriesNumberOfEpisodes[0] = newEpisodes;

                return;
            }
        }
        System.out.println("\nNo series data could be found for ID: " + id);

        promptReturnToMenu();
    }

    //Removes a series from the array using its ID
    public void DeleteSeries() {
        Scanner scan = new Scanner(System.in);
        System.out.print("Enter the series ID to delete: ");
        String id = scan.nextLine();

        for (int i = 0; i < seriesCount; i++) {
            if (seriesList[i].seriesId[0].equals(id)) {
                System.out.println("---------------------------------------");
                System.out.println("Series found:");
                System.out.println(seriesList[i]);
                System.out.println("---------------------------------------");
                System.out.print("Are you sure you want to delete series " + id + "? Enter (y) to confirm: ");
                String confirm = scan.nextLine();

                if (confirm.equalsIgnoreCase("y")) {
                    //Shifts elements left to delete the item
                    for (int j = i; j < seriesCount - 1; j++) {
                        seriesList[j] = seriesList[j + 1];
                    }
                    seriesList[seriesCount - 1] = null;
                    seriesCount--;//reduces count after deletion
                    System.out.println("---------------------------------------");
                    System.out.println("Series with series ID: " + id + " was deleted!");
                    System.out.println("---------------------------------------");
                } else {
                    System.out.println("\nInvalid entry. Series was not deleted.");
                }

                promptReturnToMenu();
                return;
            }
        }

        System.out.println("\nNo series data could be found for ID: " + id);
        promptReturnToMenu();
    }

    //Prints a report of all stored series, one by one.
    public void SeriesReport() {

        if (seriesCount == 0) {
            System.out.println("No series available to display.");
            return;
        }

        for (int i = 0; i < seriesCount; i++) {
            System.out.println("\n---------------------------------");
            System.out.println("Series " + (i + 1));
            System.out.println("---------------------------------");
            System.out.println(seriesList[i]);
            System.out.println("---------------------------------");
        }

        promptReturnToMenu();

    }

    //Ends the program completely by calling System.exit(0).
    public void ExitSeriesApplication() {
        System.out.println("Exiting the Series Application");
        System.out.println("Goodbye!");
        System.exit(0);
    }

    //my own additional utility method to display "return to menu or exit" prompt
    public void promptReturnToMenu() {
        Scanner scan = new Scanner(System.in);
        System.out.println("\nEnter (1) to launch menu or any other key to exit");
        String choice = scan.nextLine();
        if (!choice.equals("1")) {
            ExitSeriesApplication();
        }
    }

}
