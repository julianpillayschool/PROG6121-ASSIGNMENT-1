package com.mycompany.series;

public class SeriesModel {

    //Arrays hold multiple values for each series attribute
    public String[] seriesId = new String[1];
    public String[] seriesName = new String[1];
    public String[] seriesAge = new String[1];
    public String[] seriesNumberOfEpisodes = new String[1];

    //Constructor stores each input value into its respective array slot
    public SeriesModel(String seriesId, String seriesName, String seriesAge, String seriesNumberOfEpisodes) {
        this.seriesId[0] = seriesId;
        this.seriesName[0] = seriesName;
        this.seriesAge[0] = seriesAge;
        this.seriesNumberOfEpisodes[0] = seriesNumberOfEpisodes;
    }

    //Returns a nicely formatted string representing all the details of this series
    @Override
    public String toString() {
        return "Series ID: " + seriesId[0] + "\n"
                + "Series Name: " + seriesName[0] + "\n"
                + "Age Restriction: " + seriesAge[0] + "\n"
                + "Number of Episode: " + seriesNumberOfEpisodes[0];
    }
}
