package com.mycompany.series;

import java.util.Random;
import java.util.Scanner;

//Subclass for RockPaperScissors, which extends the game class to function
public class RockPaperScissors extends Game {

    private String playerName;
    private int playerScore;
    private int computerScore;
    private final String[] choices = {"rock", "paper", "scissors"};

    //Constructor
    public RockPaperScissors(String gameName, String playerName, int maxRounds) {
        super(gameName, maxRounds); //calls the parent constructor
        this.playerName = playerName;
        this.playerScore = 0;
        this.computerScore = 0;
    }

    //Getters and Setters
    public String getPlayerName() {
        return playerName;
    }

    public int getPlayerScore() {
        return playerScore;
    }

    public int getComputerScore() {
        return computerScore;
    }

    private void addPlayerScore() {
        playerScore++;
    }

    private void addComputerScore() {
        computerScore++;
    }
    
    //the main game loop
    @Override
    public void play() {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        System.out.println("Welcome to " + getName() + "!");
        boolean keepPlaying = true;

        //Continues until player quits or max rounds reached
        while (keepPlaying && getRoundCount() < getHistory().length) {
            System.out.print("\nEnter rock, paper, scissors (or quit): ");
            String userChoice = scanner.nextLine().toLowerCase();

            //Allows player to exit
            if (userChoice.equals("quit")) {
                keepPlaying = false;
                break;
            }

            //Validates input
            if (!(userChoice.equals("rock") || userChoice.equals("paper") || userChoice.equals("scissors"))) {
                System.out.println("Invalid input. Please enter only 'rock', 'paper', or 'scissors'.");
                continue; //Skips the round and asks again if the input is invalid
            }

            //Computer randomly selects a move using the random utility import (ChatGPT was used for assistance on obtaining how to randomize choices and inputing the "random" utility)
            String computerChoice = choices[random.nextInt(3)];
            System.out.println("Computer chose: " + computerChoice);

            //Determines round winner
            String winner;
            if (userChoice.equals(computerChoice)) {
                winner = "Tie";
            } else if ((userChoice.equals("rock") && computerChoice.equals("scissors"))
                    || (userChoice.equals("scissors") && computerChoice.equals("paper"))
                    || (userChoice.equals("paper") && computerChoice.equals("rock"))) {
                winner = playerName;
                addPlayerScore();
            } else {
                winner = "Computer";
                addComputerScore();
            }

            addResult(userChoice, computerChoice, winner); //stores result in the 2D array
            System.out.println("Winner: " + winner);
        }

        //shows a game summary
        showReport();
    }

    //Reports all rounds and final scores
    private void showReport() {
        System.out.println("\n===== GAME REPORT =====");
        for (int i = 0; i < getRoundCount(); i++) {
            System.out.println("Round " + (i + 1) + ": Player -> " + getHistory()[i][0]
                    + ", Computer -> " + getHistory()[i][1]
                    + ", Winner -> " + getHistory()[i][2]);
        }
        System.out.println("\nFinal Scores:");
        System.out.println(playerName + ": " + getPlayerScore());
        System.out.println("Computer: " + getComputerScore());
    }

    //Main method to run the game
    public static void main(String[] args) {
        RockPaperScissors game = new RockPaperScissors("Rock Paper Scissors", "Player1", 5);
        game.play();
    }
}
