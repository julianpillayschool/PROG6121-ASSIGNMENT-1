
package com.mycompany.series;

import java.util.Random;
import java.util.Scanner;

// Base Class that will be inherited from for the rock , paper, scissors game
abstract class Game {
    private String name;
    private String[][] history; // use of 2D Array for [round][player/computer/winner]
    private int roundCount; // the number of rounds so far

    // Constructor which creates a game with a name and max rounds
    public Game(String name, int maxRounds) {
        this.name = name;
        this.history = new String[maxRounds][3]; // 3 columns: player, computer, winner
        this.roundCount = 0;
    }

    // Getters and setters that make use of information hiding 
    public String getName() {
        return name;
    }

    public String[][] getHistory() {
        return history;
    }

    public int getRoundCount() {
        return roundCount;
    }

    protected void addResult(String playerMove, String computerMove, String winner) {
        if (roundCount < history.length) { //only adds if space remains
            history[roundCount][0] = playerMove; //collumn 0 = player
            history[roundCount][1] = computerMove; //collumn 1 = computer
            history[roundCount][2] = winner; //collumn 2 = winner
            roundCount++; //moves to the next round
        }
    }

    public abstract void play(); // abstract method for each game to be implemented by child class
}