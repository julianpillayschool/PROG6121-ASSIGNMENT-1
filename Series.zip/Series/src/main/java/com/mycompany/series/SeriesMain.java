package com.mycompany.series;

import java.util.Scanner;

public class SeriesMain {

    public static void main(String[] args) {
        Series app = new Series();
        Scanner scan = new Scanner(System.in);

        System.out.println("Latest Series - 2025");
        System.out.println("*************************************");
        System.out.println("Enter (1) to launch menu or any other key to exit");
        String startChoice = scan.nextLine();
        if (!startChoice.equals("1")) {//if the user doesnt enter "1" then exit the application entirely 
            app.ExitSeriesApplication();
        }

        //prompts the user to select one of the options displayed on the menu, using switch and cases
        while (true) {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new series.");
            System.out.println("(2) Search for a series.");
            System.out.println("(3) Update a series.");
            System.out.println("(4) Delete a series.");
            System.out.println("(5) Print series report - 2025");
            System.out.println("(6) Exit Application.");

            String choice = scan.nextLine();

            switch (choice) {
                case "1":
                    app.CaptureSeries();
                    break;
                case "2":
                    app.SearchSeries();
                    break;
                case "3":
                    app.UpdateSeries();
                    break;
                case "4":
                    app.DeleteSeries();
                    break;
                case "5":
                    app.SeriesReport();
                    break;
                case "6":
                    app.ExitSeriesApplication();
                    break;
                default:
                    System.out.println("\nInvalid choice. Please try again.");
            }
        }
    }

}
