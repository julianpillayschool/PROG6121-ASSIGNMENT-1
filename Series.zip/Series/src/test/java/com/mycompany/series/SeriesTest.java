package com.mycompany.series;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class SeriesTest {

    @BeforeEach
    //this is the set up method
    public void setUp() {
        //Resets the static array before each test
        Series.seriesList = new SeriesModel[50];
        Series.seriesCount = 0;

        //Inserts a sample series into the list
        Series.seriesList[Series.seriesCount++] = new SeriesModel("101", "Friends", "13", "236");
    }

    @Test
    //tests if the search for a specific series is successful
    public void TestSearchSeries() {
        SeriesModel found = null;
        for (int i = 0; i < Series.seriesCount; i++) {
            if (Series.seriesList[i].seriesId[0].equals("101")) {
                found = Series.seriesList[i];
                break;
            }
        }
        assertNotNull(found);//confirms it was found
        assertEquals("Friends", found.seriesName[0]);//confirms the correct series
    }

    @Test
    //tests if the search for a specific series is unsuccessful
    public void TestSearchSeries_SeriesNotFound() {
        SeriesModel found = null;
        for (int i = 0; i < Series.seriesCount; i++) {
            if (Series.seriesList[i].seriesId[0].equals("999")) {
                found = Series.seriesList[i];
                break;
            }
        }
        assertNull(found);//no series should be found
    }

    @Test
    public void TestUpdateSeries() {
        boolean updated = false;
        for (int i = 0; i < Series.seriesCount; i++) {
            if (Series.seriesList[i].seriesId[0].equals("101")) {
                Series.seriesList[i].seriesName[0] = "Friends Updated";
                Series.seriesList[i].seriesAge[0] = "15";
                Series.seriesList[i].seriesNumberOfEpisodes[0] = "240";
                updated = true;
                break;
            }
        }

        assertTrue(updated);//confirms the update happened
        assertEquals("Friends Updated", Series.seriesList[0].seriesName[0]);
        assertEquals("15", Series.seriesList[0].seriesAge[0]);
        assertEquals("240", Series.seriesList[0].seriesNumberOfEpisodes[0]);
    }

    @Test
    //tests if the deletion for a specific series is successful
    public void TestDeleteSeries() {
        boolean deleted = false;
        String deleteId = "101";

        for (int i = 0; i < Series.seriesCount; i++) {
            if (Series.seriesList[i].seriesId[0].equals(deleteId)) {
                for (int j = i; j < Series.seriesCount - 1; j++) {
                    Series.seriesList[j] = Series.seriesList[j + 1];
                }
                Series.seriesList[Series.seriesCount - 1] = null;
                Series.seriesCount--;
                deleted = true;
                break;
            }
        }

        assertTrue(deleted);
        assertEquals(0, Series.seriesCount);
        assertNull(Series.seriesList[0]);
    }

    @Test
    ////tests if the deletion for a specific series is unsuccessful
    public void TestDeleteSeries_SeriesNotFound() {
        boolean deleted = false;
        String deleteId = "999";

        for (int i = 0; i < Series.seriesCount; i++) {
            if (Series.seriesList[i].seriesId[0].equals(deleteId)) {
                deleted = true;
                break;
            }
        }

        assertFalse(deleted);//confirms deletion
        assertEquals(1, Series.seriesCount); //still has original series
    }

    @Test
    //tests if the age entry for a series is valid
    public void TestSeriesAgeRestriction_AgeValid() {
        String age = "13";
        boolean valid = false;

        if (Series.isNumeric(age)) {
            int ageNum = Integer.parseInt(age);
            valid = (ageNum >= 2 && ageNum <= 18);
        }

        assertTrue(valid);
    }

    @Test
    //tests if the age entry for a series is invalid
    public void TestSeriesAgeRestriction_SeriesAgeInValid() {
        String age = "50";
        boolean valid = false;

        if (Series.isNumeric(age)) {
            int ageNum = Integer.parseInt(age);
            valid = (ageNum >= 2 && ageNum <= 18);
        }

        assertFalse(valid);
    }
}
