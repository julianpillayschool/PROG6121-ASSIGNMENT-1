package com.mycompany.series;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class RockPaperScissorsTest {

    private RockPaperScissors game; // Test game instance

    //Creates a fresh game before each test
    @BeforeEach
    public void setUp() {
        game = new RockPaperScissors("Rock Paper Scissors", "Julian", 5);
    }

    //Tests if player name is set correctly
    @Test
    public void testGetPlayerName() {
        assertEquals("Julian", game.getPlayerName());
    }

    //Tests that player score starts at 0
    @Test
    public void testGetPlayerScoreInitiallyZero() {
        assertEquals(0, game.getPlayerScore());
    }

    //Tests that computer score starts at 0
    @Test
    public void testGetComputerScoreInitiallyZero() {
        assertEquals(0, game.getComputerScore());
    }

    //Tests a player that wins a round (rock beats scissors)
    @Test
    public void testPlayerWinsRound() {
        game.addResult("rock", "scissors", "Julian");
        assertEquals("rock", game.getHistory()[0][0]);//[0][0] = player choice in round 1
        assertEquals("scissors", game.getHistory()[0][1]);//[0][1] = computer choice in round 1
        assertEquals("Julian", game.getHistory()[0][2]);//[0][2] = winner of round 1
        assertEquals(1, game.getRoundCount());
    }

    //Tests when the computer wins a round (scissors beat paper)
    @Test
    public void testComputerWinsRound() {
        game.addResult("paper", "scissors", "Computer");
        assertEquals("paper", game.getHistory()[0][0]);
        assertEquals("scissors", game.getHistory()[0][1]);
        assertEquals("Computer", game.getHistory()[0][2]);
    }

    //Tests when theres a tie round (both rock)
    @Test
    public void testTieRound() {
        game.addResult("rock", "rock", "Tie");
        assertEquals("rock", game.getHistory()[0][0]);
        assertEquals("rock", game.getHistory()[0][1]);
        assertEquals("Tie", game.getHistory()[0][2]);
    }

    //Tests multiple different rounds 
    @Test
    public void testMultipleRounds() {
        game.addResult("rock", "scissors", "Julian");
        game.addResult("scissors", "rock", "Computer");
        game.addResult("paper", "rock", "Julian");

        assertEquals(3, game.getRoundCount());
        assertEquals("Julian", game.getHistory()[0][2]);// Winner of round 1
        assertEquals("Computer", game.getHistory()[1][2]);// Winner of round 2
        assertEquals("Julian", game.getHistory()[2][2]);// Winner of round 3
    }
}
